extern char *extractline(char *p, int size);
extern char *memnewline(char *p, int size);  /* finds \r _or_ \n */
extern char *format_ipaddr(unsigned long ipaddr);
